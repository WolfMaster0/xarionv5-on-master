﻿using OpenNos.Core.Serializing;
using OpenNos.GameObject;

namespace $rootnamespace$
{
    [PacketHeader("HEADER")]
    public class $safeitemname$
    {
        #region Properties

        // insert properties there

        #endregion

        #region Methods

        public static void HandlePacket(object session, string packet)
        {
            string[] packetSplit = packet.Split(' ');
            if (packetSplit.Length < 2) // + Amount of properties
            {
                return;
        }
            $safeitemname$ packetDefinition = new $safeitemname$();
            if (true/*check before parsing*/)
            {
                // parsing
                packetDefinition.ExecuteHandler(session as ClientSession);
            }
        }

        public static void Register() => PacketFacility.AddHandler(typeof($safeitemname$), HandlePacket);

        private void ExecuteHandler(ClientSession session)
        {
            // Code
        }

        #endregion
    }
}