﻿using OpenNos.Core.Serializing;
using OpenNos.Domain;
using OpenNos.GameObject;

namespace $rootnamespace$
{
    [PacketHeader("$HEADER", Authority = AuthorityType.GameMaster)]
public class $safeitemname$
    {
#region Members

private bool _isParsed;

#endregion

#region Properties

// insert properties there

#endregion

#region Methods

public static void HandlePacket(object session, string packet)
{
    if (session is ClientSession sess)
    {
        string[] packetSplit = packet.Split(' ');
        if (packetSplit.Length < 2) // + Amount of properties
        {
            sess.SendPacket(sess.Character.GenerateSay(ReturnHelp(), 10));
            return;
        }
        $safeitemname$ packetDefinition = new $safeitemname$();
        if (true/*check before parsing*/)
        {
            packetDefinition._isParsed = true;
            // parsing
        }
        packetDefinition.ExecuteHandler(sess);
    }
}

public static void Register() => PacketFacility.AddHandler(typeof($safeitemname$), HandlePacket);

public static string ReturnHelp() => "$HEADER";

private void ExecuteHandler(ClientSession session)
{
    if (_isParsed)
    {
        // Code
    }
    else
    {
        session.SendPacket(session.Character.GenerateSay(ReturnHelp(), 10));
    }
}

#endregion
}
}
